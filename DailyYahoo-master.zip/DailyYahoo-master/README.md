#Dialy Yahoo
- A dashboard to show activity progress